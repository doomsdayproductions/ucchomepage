# Cyberpunk-Style Glitch Walkthrough

A Pen created on CodePen.io. Original URL: [https://codepen.io/cashoutgang/pen/MWPZvMK](https://codepen.io/cashoutgang/pen/MWPZvMK).

Pure-CSS glitch effect explained. An outline of the VFX, layers, and animation